import LanguageIcon from "@mui/icons-material/Language";
import LocalPhoneIcon from "@mui/icons-material/LocalPhone";
import AttachMoneyIcon from "@mui/icons-material/AttachMoney";
import FmdGoodIcon from "@mui/icons-material/FmdGood";
import BlurCircularIcon from "@mui/icons-material/BlurCircular";
import TempleHinduIcon from "@mui/icons-material/TempleHindu";
import FlagIcon from "@mui/icons-material/Flag";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import RemoveCircleIcon from "@mui/icons-material/RemoveCircle";
import LogoutIcon from '@mui/icons-material/Logout';
export {
  LanguageIcon,
  TempleHinduIcon,
  BlurCircularIcon,
  FmdGoodIcon,
  AttachMoneyIcon,
  LocalPhoneIcon,
  FlagIcon,
  AddCircleIcon,
  RemoveCircleIcon,
  LogoutIcon
};
